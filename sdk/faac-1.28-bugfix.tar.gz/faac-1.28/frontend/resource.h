//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by faacgui.rc
//
#define IDD_MAINDIALOG                  102
#define IDC_INPUTFILENAME               1000
#define IDC_SELECT_INPUTFILE            1001
#define IDC_OUTPUTFILENAME              1002
#define IDC_SELECT_OUTPUTFILE           1003
#define IDC_INPUTPARAMS                 1004
#define IDC_PROGRESS                    1006
#define IDC_ALLOWMIDSIDE                1007
#define IDC_TIME                        1008
#define IDC_BANDWIDTH                   1009
#define IDC_QUALITY                     1010
#define IDC_USERAW                      1011
#define IDC_USETNS                      1012
#define IDC_USELFE2                     1013
#define IDC_USELFE                      1013
#define IDC_BWCTL                       1014

#define IDC_COMPILEDATE                 1018
#define IDC_MPEGVERSION                 1020
#define IDC_OBJECTTYPE                  1021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
